const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();
const port = 3000;

// Middleware для обработки JSON
app.use(express.json());

// Функция для парсинга страницы и получения Fraud Score
async function getFraudScore(ip) {
  try {
    const response = await axios.get(`https://www.ipqualityscore.com/free-ip-lookup-proxy-vpn-test`);
    const $ = cheerio.load(response.data);
    const fraudScore = $('#fraud-score').text(); // Предполагаем, что элемент с ID 'fraud-score' содержит нужное значение
    return parseInt(fraudScore, 10);
  } catch (error) {
    console.error('Ошибка при парсинге страницы:', error);
    return null;
  }
}

// Маршрут для проверки IP
app.post('/check-ip', async (req, res) => {
  const { ip } = req.body;
  const fraudScore = await getFraudScore(ip);

  if (fraudScore === null) {
    return res.status(500).json({ error: 'Ошибка при получении Fraud Score' });
  }

  if (fraudScore === 0) {
    return res.json({ status: 'valid', ip });
  } else {
    return res.json({ status: 'invalid', ip });
  }
});

app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});

let blacklist = [];

app.post('/add-to-blacklist', (req, res) => {
  const { ip } = req.body;
  if (!blacklist.includes(ip)) {
    blacklist.push(ip);
  }
  res.json({ status: 'added', ip });
});

app.post('/remove-from-blacklist', (req, res) => {
  const { ip } = req.body;
  blacklist = blacklist.filter(item => item !== ip);
  res.json({ status: 'removed', ip });
});

app.get('/blacklist', (req, res) => {
  res.json(blacklist);
});

function checkByOctets(ip, list) {
    const [a, b, c] = ip.split('.');
    return list.some(item => {
      const [x, y, z] = item.split('.');
      return a === x && b === y && c === z;
    });
  }
  
  app.post('/check-ip', async (req, res) => {
    const { ip, checkByOctets } = req.body;
  
    if (checkByOctets && checkByOctets(ip, blacklist)) {
      return res.json({ status: 'blacklisted', ip });
    }
  
    const fraudScore = await getFraudScore(ip);
  
    if (fraudScore === null) {
      return res.status(500).json({ error: 'Ошибка при получении Fraud Score' });
    }
  
    if (fraudScore === 0) {
      return res.json({ status: 'valid', ip });
    } else {
      return res.json({ status: 'invalid', ip });
    }
  });